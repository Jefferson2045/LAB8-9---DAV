﻿namespace Bussines
{
    public class Class1
    {

    }
}