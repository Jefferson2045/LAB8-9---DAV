﻿namespace Entity
{
    public class Class1
    {

    }
}