﻿namespace LibreriaClases
{
    public class Data
    {

    }
}